from .main import get_voices
from .main import make_tts
from .main import example_text
# from .text_blocks import make_text_blocks
